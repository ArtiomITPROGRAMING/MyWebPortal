const pianoKeys = document.querySelectorAll(".piano-keys .key");
let audioContext = new (window.AudioContext || window.webkitAudioContext)();

// Частоты нот (C4, C#4, D4...)
const notesFreq = {
    'a': 261.63, // C (До)
    'w': 277.18,
    's': 293.66, // D (Ре)
    'e': 311.13,
    'd': 329.63, // E (Ми)
    'f': 349.23, // F (Фа)
    't': 369.99,
    'g': 392.00, // G (Соль)
    'y': 415.30,
    'h': 440.00, // A (Ля)
    'u': 466.16,
    'j': 493.88, // B (Си)
    'k': 523.25  // C (До след. октавы)
};

const playTune = (key) => {
    if (!notesFreq[key]) return;

    // 1. Визуальный эффект
    const clickedKey = document.querySelector(`[data-key="${key}"]`);
    clickedKey.classList.add("active");
    setTimeout(() => clickedKey.classList.remove("active"), 150);

    // 2. Генерация звука (Осциллятор)
    const osc = audioContext.createOscillator();
    const gainNode = audioContext.createGain();

    osc.type = 'sine'; // Форма волны (мягкий звук)
    osc.frequency.value = notesFreq[key];

    osc.connect(gainNode);
    gainNode.connect(audioContext.destination);

    osc.start();

    // Плавное затухание звука
    gainNode.gain.exponentialRampToValueAtTime(0.00001, audioContext.currentTime + 1);
    osc.stop(audioContext.currentTime + 1);
}

// Клик мышкой
pianoKeys.forEach(key => {
    key.addEventListener("click", () => playTune(key.dataset.key));
});

// Нажатие клавиш клавиатуры
document.addEventListener("keydown", (e) => {
    playTune(e.key.toLowerCase());
});