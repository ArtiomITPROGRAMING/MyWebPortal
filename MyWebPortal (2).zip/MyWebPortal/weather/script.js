const apiKey = "656f1bc158ebd964df39c395ddf2915d";
const apiUrl = "https://api.openweathermap.org/data/2.5/weather?units=metric&lang=ru&q=";

const searchBox = document.getElementById("cityInput");
const searchBtn = document.getElementById("searchBtn");
const weatherIcon = document.querySelector(".weather-icon");
const weatherInfo = document.getElementById("weatherInfo");

async function checkWeather(city) {
    if (!city) return;

    try {
        console.log("Пробуем подключиться к API...");
        const response = await fetch(apiUrl + city + `&appid=${apiKey}`);

        // СЦЕНАРИЙ 1: Ключ еще не готов (Ошибка 401)
        if (response.status == 401) {
            console.warn("Ключ еще не активировался. Включаю ДЕМО-РЕЖИМ.");
            showDemoData(city); // Показываем фейковые данные
            alert("Ключ еще активируется (это займет время). Пока показываю демо-данные.");
            return;
        }

        // СЦЕНАРИЙ 2: Город не найден (Ошибка 404)
        if (response.status == 404) {
            alert("Город не найден! Проверьте название.");
            return;
        }

        // СЦЕНАРИЙ 3: Всё отлично (Реальная погода)
        var data = await response.json();

        document.getElementById("city").innerText = data.name;
        document.getElementById("temp").innerText = Math.round(data.main.temp) + "°C";
        document.getElementById("humidity").innerText = data.main.humidity + "%";
        document.getElementById("wind").innerText = Math.round(data.wind.speed) + " км/ч";

        // Ставим иконку от сервиса
        const iconCode = data.weather[0].icon;
        weatherIcon.src = `https://openweathermap.org/img/wn/${iconCode}@2x.png`;

        weatherInfo.style.display = "block";

    } catch (error) {
        // Если интернета вообще нет
        console.error("Ошибка сети:", error);
        showDemoData(city); // Тоже покажем демо
    }
}

// Функция для показа ненастоящих данных (пока ждем ключ)
function showDemoData(city) {
    const randomTemp = Math.floor(Math.random() * 30);
    const randomHumidity = Math.floor(Math.random() * 50) + 40;

    document.getElementById("city").innerText = city + " (Демо)";
    document.getElementById("temp").innerText = randomTemp + "°C";
    document.getElementById("humidity").innerText = randomHumidity + "%";
    document.getElementById("wind").innerText = "10 км/ч";

    // Ставим картинку солнца для примера
    weatherIcon.src = "https://openweathermap.org/img/wn/01d@2x.png";
    weatherInfo.style.display = "block";
}

searchBtn.addEventListener("click", () => {
    checkWeather(searchBox.value);
});

searchBox.addEventListener("keypress", (event) => {
    if (event.key === "Enter") {
        checkWeather(searchBox.value);
    }
});