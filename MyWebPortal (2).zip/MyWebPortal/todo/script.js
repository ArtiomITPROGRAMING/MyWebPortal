const input = document.getElementById('todoInput');
const addBtn = document.getElementById('addBtn');
const list = document.getElementById('todoList');
const countSpan = document.getElementById('count');
const clearBtn = document.getElementById('clearBtn');

// 1. При загрузке страницы достаем задачи из памяти браузера
let todos = JSON.parse(localStorage.getItem('my_todos')) || [];
renderTodos();

// 2. Функция добавления задачи
function addTodo() {
    const text = input.value.trim();
    if (text !== '') {
        const newTodo = {
            id: Date.now(),
            text: text,
            completed: false
        };
        todos.push(newTodo);
        saveAndRender();
        input.value = '';
    }
}

// 3. Функция отрисовки списка
function renderTodos() {
    list.innerHTML = '';
    let pendingCount = 0;

    todos.forEach(todo => {
        const li = document.createElement('li');
        li.className = todo.completed ? 'completed' : '';

        // Считаем активные задачи
        if (!todo.completed) pendingCount++;

        li.innerHTML = `
            <span onclick="toggleTodo(${todo.id})">${todo.text}</span>
            <button class="delete-btn" onclick="deleteTodo(${todo.id})">❌</button>
        `;
        list.appendChild(li);
    });

    countSpan.innerText = pendingCount;
}

// 4. Переключение статуса (сделано / не сделано)
window.toggleTodo = function (id) {
    todos = todos.map(todo => {
        if (todo.id === id) {
            return { ...todo, completed: !todo.completed };
        }
        return todo;
    });
    saveAndRender();
}

// 5. Удаление задачи
window.deleteTodo = function (id) {
    todos = todos.filter(todo => todo.id !== id);
    saveAndRender();
}

// 6. Сохранение в LocalStorage
function saveAndRender() {
    localStorage.setItem('my_todos', JSON.stringify(todos));
    renderTodos();
}

// Слушатели событий
addBtn.addEventListener('click', addTodo);
input.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') addTodo();
});
clearBtn.addEventListener('click', () => {
    todos = [];
    saveAndRender();
});