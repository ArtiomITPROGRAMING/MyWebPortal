const cells = document.querySelectorAll('.cell');
const statusText = document.getElementById('status');
let currentPlayer = "X";
let board = ["", "", "", "", "", "", "", "", ""];
let gameActive = true;

const winConditions = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8], // Ряды
    [0, 3, 6], [1, 4, 7], [2, 5, 8], // Колонки
    [0, 4, 8], [2, 4, 6]             // Диагонали
];

cells.forEach(cell => cell.addEventListener('click', cellClicked));

function cellClicked() {
    const index = this.getAttribute('data-index');

    if (board[index] !== "" || !gameActive) return;

    updateCell(this, index);
    checkWinner();
}

function updateCell(cell, index) {
    board[index] = currentPlayer;
    cell.textContent = currentPlayer;
    cell.style.color = currentPlayer === "X" ? "#ff6b6b" : "#48dbfb";
}

function changePlayer() {
    currentPlayer = currentPlayer === "X" ? "O" : "X";
    statusText.textContent = currentPlayer;
}

function checkWinner() {
    let roundWon = false;

    for (let i = 0; i < winConditions.length; i++) {
        const [a, b, c] = winConditions[i];
        if (board[a] && board[a] === board[b] && board[a] === board[c]) {
            roundWon = true;
            break;
        }
    }

    if (roundWon) {
        statusText.textContent = `${currentPlayer} Победил! 🎉`;
        gameActive = false;
    } else if (!board.includes("")) {
        statusText.textContent = "Ничья! 🤝";
    } else {
        changePlayer();
    }
}

function restartGame() {
    currentPlayer = "X";
    board = ["", "", "", "", "", "", "", "", ""];
    statusText.textContent = currentPlayer;
    gameActive = true;
    cells.forEach(cell => {
        cell.textContent = "";
        cell.style.background = "#444";
    });
}