const grid = document.querySelector(".cards-grid");
// Массив эмодзи (пары)
const items = ["🍎", "🍎", "🍌", "🍌", "🍒", "🍒", "🍇", "🍇", "🍉", "🍉", "🥝", "🥝", "🍍", "🍍", "🥥", "🥥"];

let firstCard = null;
let secondCard = null;
let lockBoard = false; // Блокировка нажатий во время анимации

function shuffle(array) {
    return array.sort(() => 0.5 - Math.random());
}

function createBoard() {
    grid.innerHTML = "";
    const shuffled = shuffle([...items]);

    shuffled.forEach(item => {
        const card = document.createElement("div");
        card.classList.add("card");
        card.innerHTML = `<span>${item}</span>`;
        card.addEventListener("click", flipCard);
        grid.appendChild(card);
    });
}

function flipCard() {
    if (lockBoard) return;
    if (this === firstCard) return; // Нельзя нажать на ту же карту

    this.classList.add("flip");

    if (!firstCard) {
        firstCard = this;
        return;
    }

    secondCard = this;
    checkMatch();
}

function checkMatch() {
    let isMatch = firstCard.innerHTML === secondCard.innerHTML;

    if (isMatch) {
        disableCards();
    } else {
        unflipCards();
    }
}

function disableCards() {
    firstCard.classList.add("matched");
    secondCard.classList.add("matched");
    resetBoard();
}

function unflipCards() {
    lockBoard = true;
    setTimeout(() => {
        firstCard.classList.remove("flip");
        secondCard.classList.remove("flip");
        resetBoard();
    }, 1000);
}

function resetBoard() {
    [firstCard, secondCard, lockBoard] = [null, null, false];
}

function restartGame() {
    createBoard();
}

createBoard();