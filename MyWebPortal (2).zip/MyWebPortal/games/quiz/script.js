// --- ВОПРОСЫ (Можешь менять и добавлять свои!) ---
let questions = [
    {
        numb: 1,
        question: "Что означает HTML?",
        answer: "Hyper Text Markup Language",
        options: [
            "Hyper Text Preprocessor",
            "Hyper Text Markup Language",
            "Hyper Text Multiple Language",
            "Hyper Tool Multi Language"
        ]
    },
    {
        numb: 2,
        question: "Какой язык используется для стилизации?",
        answer: "CSS",
        options: [
            "HTML",
            "JQuery",
            "CSS",
            "XML"
        ]
    },
    {
        numb: 3,
        question: "Какая планета самая большая в Солнечной системе?",
        answer: "Юпитер",
        options: [
            "Земля",
            "Марс",
            "Юпитер",
            "Сатурн"
        ]
    },
    {
        numb: 4,
        question: "Сколько бит в одном байте?",
        answer: "8",
        options: [
            "1",
            "4",
            "8",
            "16"
        ]
    },
    {
        numb: 5,
        question: "Столица Франции?",
        answer: "Париж",
        options: [
            "Лондон",
            "Берлин",
            "Рим",
            "Париж"
        ]
    },
];

// --- ЛОГИКА ИГРЫ ---

const quizBox = document.querySelector(".quiz-box");
const resultBox = document.querySelector(".result_box");
const option_list = document.querySelector(".option_list");
const time_line = document.querySelector("header .time_line");
const timeText = document.querySelector(".timer .time_left_txt");
const timeCount = document.querySelector(".timer .timer_sec");

const restart_quiz = document.querySelector(".buttons .restart");
const quit_quiz = document.querySelector(".buttons .quit");
const next_btn = document.querySelector("footer .next_btn");
const bottom_ques_counter = document.querySelector("footer .total_que");

let timeValue = 15;
let que_count = 0;
let que_numb = 1;
let userScore = 0;
let counter;
let counterLine;
let widthValue = 0;

// Если нажали "Заново"
restart_quiz.onclick = () => {
    quizBox.classList.remove("hide");
    resultBox.classList.remove("activeResult");
    timeValue = 15;
    que_count = 0;
    que_numb = 1;
    userScore = 0;
    widthValue = 0;
    showQuetions(que_count);
    queCounter(que_numb);
    clearInterval(counter);
    clearInterval(counterLine);
    startTimer(timeValue);
    next_btn.classList.remove("show");
}

// Если нажали "Выход"
quit_quiz.onclick = () => {
    window.location.href = "../index.html";
}

// Если нажали "Далее"
next_btn.onclick = () => {
    if (que_count < questions.length - 1) {
        que_count++;
        que_numb++;
        showQuetions(que_count);
        queCounter(que_numb);
        clearInterval(counter);
        clearInterval(counterLine);
        startTimer(timeValue);
        next_btn.classList.remove("show");
    } else {
        clearInterval(counter);
        clearInterval(counterLine);
        showResult();
    }
}

// Показать вопрос
function showQuetions(index) {
    const que_text = document.querySelector(".que_text");

    let que_tag = '<span>' + questions[index].numb + ". " + questions[index].question + '</span>';
    let option_tag = '<div class="option"><span>' + questions[index].options[0] + '</span></div>'
        + '<div class="option"><span>' + questions[index].options[1] + '</span></div>'
        + '<div class="option"><span>' + questions[index].options[2] + '</span></div>'
        + '<div class="option"><span>' + questions[index].options[3] + '</span></div>';

    que_text.innerHTML = que_tag;
    option_list.innerHTML = option_tag;

    const option = option_list.querySelectorAll(".option");

    // Добавить onclick каждому варианту
    for (i = 0; i < option.length; i++) {
        option[i].setAttribute("onclick", "optionSelected(this)");
    }
}

// Когда вариант выбран
function optionSelected(answer) {
    clearInterval(counter);
    clearInterval(counterLine);
    let userAns = answer.textContent;
    let correcAns = questions[que_count].answer;
    const allOptions = option_list.children.length;

    if (userAns == correcAns) {
        userScore += 1;
        answer.classList.add("correct");
    } else {
        answer.classList.add("incorrect");
        // Если неправильно, подсветить правильный
        for (i = 0; i < allOptions; i++) {
            if (option_list.children[i].textContent == correcAns) {
                option_list.children[i].setAttribute("class", "option correct");
            }
        }
    }

    // Отключить все варианты
    for (i = 0; i < allOptions; i++) {
        option_list.children[i].classList.add("disabled");
    }
    next_btn.classList.add("show");
}

// Результаты
function showResult() {
    quizBox.classList.add("hide");
    resultBox.classList.add("activeResult");
    const scoreText = document.querySelector(".score_text");

    if (userScore > 3) {
        let scoreTag = '<span>Поздравляю! Ты набрал <p>' + userScore + '</p> из <p>' + questions.length + '</p></span>';
        scoreText.innerHTML = scoreTag;
    }
    else if (userScore > 1) {
        let scoreTag = '<span>Неплохо! Ты набрал <p>' + userScore + '</p> из <p>' + questions.length + '</p></span>';
        scoreText.innerHTML = scoreTag;
    }
    else {
        let scoreTag = '<span>Печально, ты набрал всего <p>' + userScore + '</p> из <p>' + questions.length + '</p></span>';
        scoreText.innerHTML = scoreTag;
    }
}

// Таймер
function startTimer(time) {
    counter = setInterval(timer, 1000);
    function timer() {
        timeCount.textContent = time;
        time--;
        if (time < 9) {
            let addZero = timeCount.textContent;
            timeCount.textContent = "0" + addZero;
        }
        if (time < 0) {
            clearInterval(counter);
            timeCount.textContent = "00";
            const allOptions = option_list.children.length;
            let correcAns = questions[que_count].answer;

            for (i = 0; i < allOptions; i++) {
                if (option_list.children[i].textContent == correcAns) {
                    option_list.children[i].setAttribute("class", "option correct");
                }
            }
            for (i = 0; i < allOptions; i++) {
                option_list.children[i].classList.add("disabled");
            }
            next_btn.classList.add("show");
        }
    }
}

// Счетчик вопросов внизу
function queCounter(index) {
    let totalQueCounTag = '<span><p>' + index + '</p> из <p>' + questions.length + '</p></span>';
    bottom_ques_counter.innerHTML = totalQueCounTag;
}

// Запуск
showQuetions(0);
queCounter(1);
startTimer(15);