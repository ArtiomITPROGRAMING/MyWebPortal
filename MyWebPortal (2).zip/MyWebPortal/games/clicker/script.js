let score = 0;
let clickPower = 1;
let autoPower = 0;

let costClick = 10;
let costAuto = 50;

const scoreEl = document.getElementById('score');
const cookie = document.getElementById('cookie');

cookie.addEventListener('click', () => {
    score += clickPower;
    updateUI();

    // Анимация
    cookie.style.transform = "scale(0.95)";
    setTimeout(() => cookie.style.transform = "scale(1)", 50);
});

function buyUpgrade(type) {
    if (type === 'click' && score >= costClick) {
        score -= costClick;
        clickPower++;
        costClick = Math.floor(costClick * 1.5);
    } else if (type === 'auto' && score >= costAuto) {
        score -= costAuto;
        autoPower++;
        costAuto = Math.floor(costAuto * 1.5);
    }
    updateUI();
}

function updateUI() {
    scoreEl.innerText = score;
    document.getElementById('costClick').innerText = costClick;
    document.getElementById('costAuto').innerText = costAuto;

    // Блокируем кнопки, если нет денег
    document.getElementById('buyClick').disabled = score < costClick;
    document.getElementById('buyAuto').disabled = score < costAuto;
}

// Авто-кликер (каждую секунду)
setInterval(() => {
    if (autoPower > 0) {
        score += autoPower;
        updateUI();
    }
}, 1000);