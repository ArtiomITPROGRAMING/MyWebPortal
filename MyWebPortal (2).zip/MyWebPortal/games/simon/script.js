let buttonColours = ["green", "red", "yellow", "blue"];
let gamePattern = [];
let userClickedPattern = [];
let started = false;
let level = 0;

// Ссылки на звуки (используем стабильные хостинги)
const sounds = {
    "green": "https://s3.amazonaws.com/freecodecamp/simonSound1.mp3",
    "red": "https://s3.amazonaws.com/freecodecamp/simonSound2.mp3",
    "yellow": "https://s3.amazonaws.com/freecodecamp/simonSound3.mp3",
    "blue": "https://s3.amazonaws.com/freecodecamp/simonSound4.mp3",
    "wrong": "https://s3.amazonaws.com/freecodecamp/simonSound4.mp3" // Звук ошибки
};

// Старт игры (клавиатура или тап)
document.addEventListener("keydown", function () {
    if (!started) {
        document.querySelector("#level-title").innerText = "Уровень " + level;
        nextSequence();
        started = true;
    }
});

document.querySelector("h1").addEventListener("click", function () {
    if (!started) {
        document.querySelector("#level-title").innerText = "Уровень " + level;
        nextSequence();
        started = true;
    }
});

// Обработка клика игрока
const buttons = document.querySelectorAll(".btn");
buttons.forEach(btn => {
    btn.addEventListener("click", function () {
        if (!started) return; // Не реагируем, пока игра не началась

        let userChosenColour = this.id;
        userClickedPattern.push(userChosenColour);

        playSound(userChosenColour); // <--- ИГРАЕМ ЗВУК
        animatePress(userChosenColour);
        checkAnswer(userClickedPattern.length - 1);
    });
});

function checkAnswer(currentLevel) {
    if (gamePattern[currentLevel] === userClickedPattern[currentLevel]) {
        if (userClickedPattern.length === gamePattern.length) {
            setTimeout(function () {
                nextSequence();
            }, 1000);
        }
    } else {
        // ОШИБКА
        playSound("wrong"); // <--- ЗВУК ОШИБКИ

        document.querySelector("body").classList.add("game-over");
        document.querySelector("#level-title").innerText = "Ошибка! Нажми сюда для рестарта";

        setTimeout(function () {
            document.querySelector("body").classList.remove("game-over");
        }, 200);

        startOver();
    }
}

function nextSequence() {
    userClickedPattern = [];
    level++;
    document.querySelector("#level-title").innerText = "Уровень " + level;

    let randomNumber = Math.floor(Math.random() * 4);
    let randomChosenColour = buttonColours[randomNumber];
    gamePattern.push(randomChosenColour);

    // Компьютер показывает цвет
    setTimeout(() => {
        let activeBtn = document.getElementById(randomChosenColour);

        // Визуальный эффект (мигание)
        activeBtn.style.opacity = "0.3";
        setTimeout(() => activeBtn.style.opacity = "1", 100); // Убрал jQuery fade

        playSound(randomChosenColour); // <--- ИГРАЕМ ЗВУК
    }, 500);
}

// Функция воспроизведения звука
function playSound(name) {
    // Создаем новый аудио объект для каждого звука
    let audio = new Audio(sounds[name]);

    // Если это ошибка, можно сделать звук пониже или другой (тут используется 4-й звук для простоты)
    if (name === "wrong") {
        // Можно заменить ссылку выше на специфический звук проигрыша, если найдешь
        let wrongAudio = new Audio("https://www.soundjay.com/misc/sounds/fail-buzzer-01.mp3");
        wrongAudio.volume = 0.5;
        wrongAudio.play();
    } else {
        audio.play();
    }
}

function animatePress(currentColor) {
    let activeBtn = document.querySelector("." + currentColor);
    activeBtn.classList.add("pressed");
    setTimeout(function () {
        activeBtn.classList.remove("pressed");
    }, 100);
}

function startOver() {
    level = 0;
    gamePattern = [];
    started = false;
}