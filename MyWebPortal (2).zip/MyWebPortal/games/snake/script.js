const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const scoreEl = document.getElementById('score');

// Настройки
const gridSize = 20; // Размер клетки
const tileCount = canvas.width / gridSize;

let score = 0;
let velocityX = 0;
let velocityY = 0;
let snake = [{ x: 10, y: 10 }]; // Голова змеи
let food = { x: 15, y: 15 };
let gameInterval;

// Запуск игры
window.onload = () => {
    document.addEventListener('keydown', changeDirection);
    gameInterval = setInterval(gameLoop, 1000 / 10); // 10 кадров в секунду (скорость)
};

function gameLoop() {
    update();
    draw();
}

function update() {
    // Двигаем голову
    const head = { x: snake[0].x + velocityX, y: snake[0].y + velocityY };

    // Проверка на столкновение с границами (проход сквозь стены)
    if (head.x < 0) head.x = tileCount - 1;
    if (head.x >= tileCount) head.x = 0;
    if (head.y < 0) head.y = tileCount - 1;
    if (head.y >= tileCount) head.y = 0;

    // Проверка на столкновение с хвостом
    for (let i = 0; i < snake.length; i++) {
        if (head.x === snake[i].x && head.y === snake[i].y && snake.length > 1) {
            resetGame();
            return;
        }
    }

    snake.unshift(head); // Добавляем новую голову

    // Проверка еды
    if (head.x === food.x && head.y === food.y) {
        score++;
        scoreEl.innerText = score;
        spawnFood();
    } else {
        snake.pop(); // Убираем хвост, если не поели
    }
}

function draw() {
    // Очистка фона
    ctx.fillStyle = '#161b22';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Рисуем змею
    ctx.fillStyle = '#2ecc71';
    snake.forEach((part, index) => {
        // Голова чуть светлее
        if (index === 0) ctx.fillStyle = '#4cd137';
        else ctx.fillStyle = '#2ecc71';

        ctx.fillRect(part.x * gridSize, part.y * gridSize, gridSize - 2, gridSize - 2);
    });

    // Рисуем еду
    ctx.fillStyle = '#e74c3c';
    ctx.beginPath();
    ctx.arc(food.x * gridSize + gridSize / 2, food.y * gridSize + gridSize / 2, gridSize / 2 - 2, 0, Math.PI * 2);
    ctx.fill();
}

function spawnFood() {
    food.x = Math.floor(Math.random() * tileCount);
    food.y = Math.floor(Math.random() * tileCount);

    // Не спавнить еду внутри змеи
    snake.forEach(part => {
        if (part.x === food.x && part.y === food.y) spawnFood();
    });
}

function changeDirection(event) {
    // Коды клавиш: 37(Left), 38(Up), 39(Right), 40(Down)
    if (event.keyCode == 37 && velocityX !== 1) { velocityX = -1; velocityY = 0; }
    if (event.keyCode == 38 && velocityY !== 1) { velocityX = 0; velocityY = -1; }
    if (event.keyCode == 39 && velocityX !== -1) { velocityX = 1; velocityY = 0; }
    if (event.keyCode == 40 && velocityY !== -1) { velocityX = 0; velocityY = 1; }
}

function resetGame() {
    snake = [{ x: 10, y: 10 }];
    velocityX = 0;
    velocityY = 0;
    score = 0;
    scoreEl.innerText = score;
    spawnFood();
}