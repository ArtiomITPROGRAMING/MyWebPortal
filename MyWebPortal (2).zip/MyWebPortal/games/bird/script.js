const cvs = document.getElementById("canvas");
const ctx = cvs.getContext("2d");

// Растягиваем на весь экран
cvs.width = window.innerWidth;
cvs.height = window.innerHeight;

// Переменные
let frames = 0;
const DEGREE = Math.PI / 180;

// Состояние игры
const state = {
    current: 0,
    getReady: 0,
    game: 1,
    over: 2
}

// Управление
document.addEventListener("click", function (evt) {
    switch (state.current) {
        case state.getReady:
            state.current = state.game;
            break;
        case state.game:
            bird.flap();
            break;
        case state.over:
            bird.speedReset();
            pipes.reset();
            score.reset();
            state.current = state.getReady;
            break;
    }
});

const score = {
    best: 0,
    value: 0,
    draw: function () {
        ctx.fillStyle = "#FFF";
        ctx.strokeStyle = "#000";

        if (state.current == state.game) {
            ctx.lineWidth = 2;
            ctx.font = "35px Teko";
            ctx.fillText(this.value, cvs.width / 2, 50);
            ctx.strokeText(this.value, cvs.width / 2, 50);
        } else if (state.current == state.over) {
            ctx.font = "25px Teko";
            ctx.fillText("Счет: " + this.value, cvs.width / 2 - 40, cvs.height / 2);
            ctx.fillText("Лучший: " + this.best, cvs.width / 2 - 40, cvs.height / 2 + 40);
        }
    },
    reset: function () {
        this.value = 0;
    }
}

const bird = {
    x: 50,
    y: 150,
    w: 30,
    h: 30,
    radius: 12,
    speed: 0,
    gravity: 0.25,
    jump: 4.6,

    draw: function () {
        ctx.fillStyle = "yellow";
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = "black";
        ctx.stroke();
        // Глаз
        ctx.fillStyle = "white";
        ctx.beginPath();
        ctx.arc(this.x + 5, this.y - 5, 4, 0, Math.PI * 2);
        ctx.fill();
    },

    flap: function () {
        this.speed = -this.jump;
    },

    update: function () {
        if (state.current == state.getReady) {
            this.y = 150;
        } else {
            this.speed += this.gravity;
            this.y += this.speed;

            if (this.y + this.h / 2 >= cvs.height) {
                this.y = cvs.height - this.h / 2;
                if (state.current == state.game) state.current = state.over;
            }
        }
    },
    speedReset: function () {
        this.speed = 0;
    }
}

const pipes = {
    position: [],
    w: 53,
    h: 400,
    gap: 150, // Место для пролета
    dx: 2,

    draw: function () {
        for (let i = 0; i < this.position.length; i++) {
            let p = this.position[i];
            let topY = p.y;
            let bottomY = p.y + this.h + this.gap;

            ctx.fillStyle = "#2ecc71";
            ctx.fillRect(p.x, topY, this.w, this.h);
            ctx.fillRect(p.x, bottomY, this.w, this.h);
        }
    },

    update: function () {
        if (state.current !== state.game) return;

        if (frames % 150 == 0) { // Каждые 150 кадров новая труба
            this.position.push({
                x: cvs.width,
                y: -150 * (Math.random() + 1)
            });
        }

        for (let i = 0; i < this.position.length; i++) {
            let p = this.position[i];
            let bottomPipeY = p.y + this.h + this.gap;

            // Столкновение
            if (bird.x + bird.radius > p.x && bird.x - bird.radius < p.x + this.w &&
                (bird.y - bird.radius < p.y + this.h || bird.y + bird.radius > bottomPipeY)) {
                state.current = state.over;
                score.best = Math.max(score.value, score.best);
            }

            p.x -= this.dx;

            if (p.x + this.w <= 0) {
                this.position.shift();
                score.value += 1;
                i--;
            }
        }
    },
    reset: function () {
        this.position = [];
    }
}

function draw() {
    ctx.fillStyle = "#70c5ce";
    ctx.fillRect(0, 0, cvs.width, cvs.height);
    pipes.draw();
    bird.draw();
    score.draw();

    if (state.current == state.getReady) {
        ctx.fillStyle = "black";
        ctx.font = "30px Arial";
        ctx.fillText("Кликни, чтобы начать", cvs.width / 2 - 140, cvs.height / 2);
    }

    if (state.current == state.over) {
        ctx.fillStyle = "red";
        ctx.font = "40px Arial";
        ctx.fillText("GAME OVER", cvs.width / 2 - 110, cvs.height / 2 - 50);
    }
}

function update() {
    bird.update();
    pipes.update();
}

function loop() {
    update();
    draw();
    frames++;
    requestAnimationFrame(loop);
}
loop();