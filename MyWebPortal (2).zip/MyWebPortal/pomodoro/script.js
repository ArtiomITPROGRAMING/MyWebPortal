let timer = document.getElementById('timer');
let startBtn = document.getElementById('start');
let resetBtn = document.getElementById('reset');
let workBtn = document.getElementById('workBtn');
let breakBtn = document.getElementById('breakBtn');

let timeLeft = 25 * 60; // 25 минут в секундах
let interval = null;
let isWorkMode = true;

function updateTimer() {
    let minutes = Math.floor(timeLeft / 60);
    let seconds = timeLeft % 60;

    // Добавляем нолик, если меньше 10 (09:05)
    timer.innerHTML = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
}

function startTimer() {
    if (interval) return; // Если уже идет, не запускаем второй

    interval = setInterval(() => {
        timeLeft--;
        updateTimer();

        if (timeLeft === 0) {
            clearInterval(interval);
            alert("Время вышло!");
            interval = null;
        }
    }, 1000);
}

function resetTimer() {
    clearInterval(interval);
    interval = null;
    timeLeft = isWorkMode ? 25 * 60 : 5 * 60;
    updateTimer();
}

function switchMode(mode) {
    clearInterval(interval);
    interval = null;

    if (mode === 'work') {
        isWorkMode = true;
        timeLeft = 25 * 60;
        workBtn.classList.add('active');
        breakBtn.classList.remove('active');
        document.body.classList.remove('break-mode');
    } else {
        isWorkMode = false;
        timeLeft = 5 * 60;
        breakBtn.classList.add('active');
        workBtn.classList.remove('active');
        document.body.classList.add('break-mode');
    }
    updateTimer();
}

startBtn.addEventListener('click', startTimer);
resetBtn.addEventListener('click', resetTimer);
workBtn.addEventListener('click', () => switchMode('work'));
breakBtn.addEventListener('click', () => switchMode('break'));

updateTimer();