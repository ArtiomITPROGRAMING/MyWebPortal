const container = document.getElementById('container');
const text = document.getElementById('text');

const totalTime = 7500; // 7.5 секунд на полный цикл
const breatheTime = (totalTime / 5) * 2; // 3 секунды вдох
const holdTime = totalTime / 5; // 1.5 секунды задержка

breathAnimation();

function breathAnimation() {
    // 1. Вдох
    text.innerText = 'Вдохните...';
    container.className = 'container grow';

    setTimeout(() => {
        // 2. Задержка
        text.innerText = 'Задержите...';

        setTimeout(() => {
            // 3. Выдох
            text.innerText = 'Выдохните...';
            container.className = 'container shrink';
        }, holdTime);

    }, breatheTime);
}

// Запускаем цикл бесконечно
setInterval(breathAnimation, totalTime);