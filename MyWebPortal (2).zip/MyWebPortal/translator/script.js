const fromText = document.querySelector(".from-text");
const toText = document.querySelector(".to-text");
const selectTag = document.querySelectorAll("select");
const exchangeIcon = document.querySelector(".exchange");
const translateBtn = document.querySelector("button");
const icons = document.querySelectorAll(".row i");

// 1. Заполняем выпадающие списки языками из countries.js
selectTag.forEach((tag, id) => {
    for (const country_code in countries) {
        let selected;
        // По умолчанию: Русский -> Английский
        if (id == 0 && country_code == "ru-RU") selected = "selected";
        if (id == 1 && country_code == "en-GB") selected = "selected";

        let option = `<option value="${country_code}" ${selected}>${countries[country_code]}</option>`;
        tag.insertAdjacentHTML("beforeend", option);
    }
});

// 2. Кнопка смены языков местами
exchangeIcon.addEventListener("click", () => {
    let tempText = fromText.value;
    let tempLang = selectTag[0].value;

    fromText.value = toText.value;
    selectTag[0].value = selectTag[1].value;
    toText.value = tempText;
    selectTag[1].value = tempLang;
});

// 3. Функция перевода (MyMemory API)
translateBtn.addEventListener("click", () => {
    let text = fromText.value;
    let translateFrom = selectTag[0].value; // например ru-RU
    let translateTo = selectTag[1].value;   // например en-GB

    if (!text) return;

    toText.setAttribute("placeholder", "Переводим...");

    // Формируем запрос. API просит код из двух букв (ru, en), поэтому обрезаем "ru-RU" до "ru"
    let apiUrl = `https://api.mymemory.translated.net/get?q=${text}&langpair=${translateFrom}|${translateTo}`;

    fetch(apiUrl).then(res => res.json()).then(data => {
        toText.value = data.responseData.translatedText;
        toText.setAttribute("placeholder", "Перевод");
    });
});

// 4. Иконки (Копирование и Озвучка)
icons.forEach(icon => {
    icon.addEventListener("click", ({ target }) => {
        if (target.classList.contains("fa-copy")) {
            // Копирование
            if (target.id == "from") {
                navigator.clipboard.writeText(fromText.value);
            } else {
                navigator.clipboard.writeText(toText.value);
            }
            alert("Текст скопирован!");
        } else {
            // Озвучка
            let utterance;
            if (target.id == "from") {
                utterance = new SpeechSynthesisUtterance(fromText.value);
                utterance.lang = selectTag[0].value;
            } else {
                utterance = new SpeechSynthesisUtterance(toText.value);
                utterance.lang = selectTag[1].value;
            }
            speechSynthesis.speak(utterance);
        }
    });
});