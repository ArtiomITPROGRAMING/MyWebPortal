const countries = {
    "ru-RU": "Russian",
    "en-GB": "English",
    "de-DE": "German",
    "es-ES": "Spanish",
    "fr-FR": "French",
    "it-IT": "Italian",
    "tr-TR": "Turkish",
    "uk-UA": "Ukrainian",
    "kk-KZ": "Kazakh",
    "ja-JP": "Japanese",
    "ko-KR": "Korean",
    "zh-CN": "Chinese"
}