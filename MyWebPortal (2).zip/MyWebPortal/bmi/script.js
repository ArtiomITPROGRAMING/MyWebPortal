function calculateBMI() {
    const height = document.getElementById('height').value;
    const weight = document.getElementById('weight').value;
    const result = document.getElementById('result');

    if (height === "" || weight === "") {
        result.innerHTML = "Введите оба значения!";
        result.style.color = "red";
        return;
    }

    // Формула: вес / (рост в метрах * рост в метрах)
    const bmi = (weight / ((height / 100) * (height / 100))).toFixed(1);
    let status = "";
    let color = "";

    if (bmi < 18.5) {
        status = "Недостаток веса 🌭";
        color = "#f1c40f";
    } else if (bmi >= 18.5 && bmi < 24.9) {
        status = "Норма 💪";
        color = "#27ae60";
    } else {
        status = "Избыточный вес 🍔";
        color = "#e74c3c";
    }

    result.innerHTML = `BMI: ${bmi} <br> ${status}`;
    result.style.color = color;
}