let heads = 0;
let tails = 0;
let coin = document.querySelector(".coin");
let flipBtn = document.querySelector("#flip-button");

flipBtn.addEventListener("click", () => {
    // Случайное число: 0 или 1
    let i = Math.floor(Math.random() * 2);

    // Сбрасываем анимацию
    coin.style.animation = "none";

    // Блокируем кнопку пока крутится
    flipBtn.disabled = true;

    if (i) {
        // Если 1 - Решка (Tails)
        setTimeout(function () {
            coin.style.animation = "flipTails 3s forwards";
        }, 100);
        tails++;
    } else {
        // Если 0 - Орел (Heads)
        setTimeout(function () {
            coin.style.animation = "flipHeads 3s forwards";
        }, 100);
        heads++;
    }

    // Ждем 3 секунды (пока анимация кончится)
    setTimeout(() => {
        updateStats();
        flipBtn.disabled = false;
    }, 3000);
});

function updateStats() {
    document.querySelector("#heads-count").textContent = `${heads}`;
    document.querySelector("#tails-count").textContent = `${tails}`;
}