// Элементы DOM
const imageInput = document.getElementById('imageInput');
const canvas = document.getElementById('memeCanvas');
const ctx = canvas.getContext('2d');
const downloadBtn = document.getElementById('downloadBtn');
const placeholder = document.getElementById('placeholder');

// Хранилище настроек
const settings = {
    top: {
        textInput: document.getElementById('topText'),
        sizeInput: document.getElementById('topSize'),
        colorInput: document.getElementById('topColor'),
        xInput: document.getElementById('topX'),
        yInput: document.getElementById('topY')
    },
    bottom: {
        textInput: document.getElementById('bottomText'),
        sizeInput: document.getElementById('bottomSize'),
        colorInput: document.getElementById('bottomColor'),
        xInput: document.getElementById('bottomX'),
        yInput: document.getElementById('bottomY')
    }
};

let currentImage = null;

// 1. Загрузка картинки
imageInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = (event) => {
            currentImage = new Image();
            currentImage.onload = () => {
                placeholder.style.display = 'none';
                drawMeme();
            };
            currentImage.src = event.target.result;
        };
        reader.readAsDataURL(file);
    }
});

// 2. Добавление событий на все инпуты
// Мы проходим по объекту settings и вешаем 'input' слушатель на каждый элемент
['top', 'bottom'].forEach(pos => {
    const group = settings[pos];

    // Для каждого инпута в группе (текст, размер, цвет...)
    Object.values(group).forEach(element => {
        element.addEventListener('input', drawMeme);
    });
});

// 3. Функция рисования
function drawMeme() {
    if (!currentImage) return;

    // Установка размеров холста под картинку
    canvas.width = currentImage.width;
    canvas.height = currentImage.height;

    // Рисуем фото
    ctx.drawImage(currentImage, 0, 0);

    // Рисуем верхний и нижний текст
    drawText('top');
    drawText('bottom');
}

// Вспомогательная функция отрисовки текста
function drawText(position) {
    const config = settings[position];

    const text = config.textInput.value.toUpperCase();
    const size = parseInt(config.sizeInput.value);
    const color = config.colorInput.value;

    // Вычисляем координаты (проценты от ширины/высоты картинки)
    const x = (config.xInput.value / 100) * canvas.width;
    const y = (config.yInput.value / 100) * canvas.height;

    // Настройки шрифта
    ctx.font = `900 ${size}px Impact, sans-serif`; // Жирный Impact
    ctx.fillStyle = color;
    ctx.strokeStyle = 'black';
    ctx.lineWidth = Math.max(2, size / 15); // Толщина обводки зависит от размера текста
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle'; // Центрирование по вертикали

    // Сначала рисуем обводку, потом заливку
    ctx.strokeText(text, x, y);
    ctx.fillText(text, x, y);
}

// 4. Скачивание
downloadBtn.addEventListener('click', () => {
    if (!currentImage) {
        alert('Пожалуйста, сначала загрузите картинку!');
        return;
    }
    const link = document.createElement('a');
    link.download = 'my-cool-meme.png';
    link.href = canvas.toDataURL();
    link.click();
});