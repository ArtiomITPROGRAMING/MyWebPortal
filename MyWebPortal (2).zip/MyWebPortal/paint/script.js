const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');
const colorPicker = document.getElementById('colorPicker');
const brushSize = document.getElementById('brushSize');
const clearBtn = document.getElementById('clearBtn');
const saveBtn = document.getElementById('saveBtn');

// Растягиваем холст на весь экран
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

let isDrawing = false;

// Мышь нажата - начинаем рисовать
canvas.addEventListener('mousedown', (e) => {
    isDrawing = true;
    ctx.beginPath();
    ctx.moveTo(e.clientX, e.clientY);
});

// Мышь двигается - рисуем линию
canvas.addEventListener('mousemove', (e) => {
    if (isDrawing) {
        ctx.lineTo(e.clientX, e.clientY);
        ctx.strokeStyle = colorPicker.value;
        ctx.lineWidth = brushSize.value;
        ctx.lineCap = 'round'; // Круглые концы линий
        ctx.lineJoin = 'round';
        ctx.stroke();
    }
});

// Мышь отпущена - заканчиваем
canvas.addEventListener('mouseup', () => isDrawing = false);
canvas.addEventListener('mouseout', () => isDrawing = false);

// Кнопки
clearBtn.addEventListener('click', () => ctx.clearRect(0, 0, canvas.width, canvas.height));

saveBtn.addEventListener('click', () => {
    const link = document.createElement('a');
    link.download = 'my-art.png';
    link.href = canvas.toDataURL();
    link.click();
});