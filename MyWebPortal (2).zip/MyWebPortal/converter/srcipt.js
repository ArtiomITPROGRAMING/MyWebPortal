const amount = document.getElementById('amount');
const from = document.getElementById('currencyFrom');
const to = document.getElementById('currencyTo');
const result = document.getElementById('result');
const btn = document.getElementById('convertBtn');

btn.addEventListener('click', () => {
    const codeFrom = from.value;
    const codeTo = to.value;

    // Используем бесплатный API
    fetch(`https://api.exchangerate-api.com/v4/latest/${codeFrom}`)
        .then(res => res.json())
        .then(data => {
            const rate = data.rates[codeTo];
            result.value = (amount.value * rate).toFixed(2);
        })
        .catch(() => alert('Ошибка сети!'));
});