const game = () => {
    let pScore = 0;
    let cScore = 0;

    const playMatch = () => {
        const options = document.querySelectorAll(".options button");
        const playerHand = document.querySelector(".player-hand");
        const computerHand = document.querySelector(".computer-hand");
        const hands = document.querySelectorAll(".hands img");

        // Убираем анимацию после завершения
        hands.forEach(hand => {
            hand.addEventListener("animationend", function () {
                this.style.animation = "";
            });
        });

        const computerOptions = ["rock", "paper", "scissors"];

        options.forEach(option => {
            option.addEventListener("click", function () {
                // Компьютер делает выбор
                const computerNumber = Math.floor(Math.random() * 3);
                const computerChoice = computerOptions[computerNumber];

                // Задержка для анимации (2 секунды трясем руками)
                setTimeout(() => {
                    compareHands(this.className, computerChoice);

                    // Обновляем картинки (если нет картинок, ничего страшного)
                    playerHand.src = `${this.className}.png`;
                    computerHand.src = `${computerChoice}.png`;
                }, 2000);

                // Запуск анимации
                playerHand.style.animation = "shakePlayer 2s ease";
                computerHand.style.animation = "shakeComputer 2s ease";

                // Сброс картинок на "камень" во время тряски
                playerHand.src = `rock.png`;
                computerHand.src = `rock.png`;
            });
        });
    };

    const updateScore = () => {
        document.querySelector(".player-score p").textContent = pScore;
        document.querySelector(".computer-score p").textContent = cScore;
    };

    const compareHands = (playerChoice, computerChoice) => {
        const winner = document.querySelector(".winner");

        if (playerChoice === computerChoice) {
            winner.textContent = "Ничья!";
            return;
        }

        if (playerChoice === "rock") {
            if (computerChoice === "scissors") {
                winner.textContent = "Ты победил!";
                pScore++;
                updateScore();
                return;
            } else {
                winner.textContent = "ПК победил!";
                cScore++;
                updateScore();
                return;
            }
        }

        if (playerChoice === "paper") {
            if (computerChoice === "scissors") {
                winner.textContent = "ПК победил!";
                cScore++;
                updateScore();
                return;
            } else {
                winner.textContent = "Ты победил!";
                pScore++;
                updateScore();
                return;
            }
        }

        if (playerChoice === "scissors") {
            if (computerChoice === "rock") {
                winner.textContent = "ПК победил!";
                cScore++;
                updateScore();
                return;
            } else {
                winner.textContent = "Ты победил!";
                pScore++;
                updateScore();
                return;
            }
        }
    };

    playMatch();
};

game();