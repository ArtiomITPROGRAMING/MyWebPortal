const ball = document.querySelector('.eight-ball');
const answerText = document.getElementById('answer');
const questionInput = document.getElementById('question');
const container = document.querySelector('.ball-container');

// Возможные ответы (Классические)
const answers = [
    "Бесспорно", "Предрешено", "Никаких сомнений",
    "Определенно да", "Можешь быть уверен",
    "Мне кажется — да", "Вероятнее всего", "Хорошие перспективы",
    "Знаки говорят — да", "Да",
    "Пока не ясно", "Спроси позже", "Лучше не рассказывать",
    "Сейчас нельзя предсказать", "Сконцентрируйся и спроси",
    "Даже не думай", "Мой ответ — нет", "По моим данным — нет",
    "Перспективы не очень", "Весьма сомнительно"
];

ball.addEventListener('click', () => {
    // Проверка: написал ли пользователь вопрос?
    if (questionInput.value.trim() === "") {
        alert("Сначала задай вопрос!");
        return;
    }

    // Сбрасываем предыдущий ответ
    container.classList.remove('show-answer');

    // Добавляем тряску
    ball.classList.add('shake');

    // Ждем 1 секунду (пока трясется)
    setTimeout(() => {
        ball.classList.remove('shake');

        // Выбираем случайный ответ
        const randomIndex = Math.floor(Math.random() * answers.length);
        answerText.innerText = answers[randomIndex];

        // Показываем ответ
        container.classList.add('show-answer');
    }, 1000);
});