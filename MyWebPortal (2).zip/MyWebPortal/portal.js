function openTab(tabName) {
    // 1. Скрыть все разделы с классом tab-content
    const contents = document.querySelectorAll('.tab-content');
    contents.forEach(content => {
        content.classList.remove('active-tab');
    });

    // 2. Убрать класс 'active' у всех кнопок
    const buttons = document.querySelectorAll('.tab-btn');
    buttons.forEach(btn => {
        btn.classList.remove('active');
    });

    // 3. Показать нужный раздел
    document.getElementById(tabName).classList.add('active-tab');

    // 4. Подсветить нажатую кнопку
    // (Ищем кнопку, у которой в onclick написано имя таба)
    const clickedBtn = document.querySelector(`button[onclick="openTab('${tabName}')"]`);
    clickedBtn.classList.add('active');
}

// Функция для настроек (очистка данных задач)
function clearLocalStorage() {
    if (confirm("Вы точно хотите удалить все сохраненные задачи?")) {
        localStorage.removeItem('my_todos');
        alert("Данные очищены!");
    }
}

function updateClock() {
    const now = new Date();

    // Время
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    document.getElementById('main-time').innerText = `${hours}:${minutes}`;

    // Дата (на русском)
    const options = { weekday: 'long', day: 'numeric', month: 'long' };
    const dateString = now.toLocaleDateString('ru-RU', options);

    // Делаем первую букву заглавной (понедельник -> Понедельник)
    document.getElementById('main-date').innerText = dateString.charAt(0).toUpperCase() + dateString.slice(1);
}

// Запускаем сразу и обновляем каждую секунду
setInterval(updateClock, 1000);
updateClock();