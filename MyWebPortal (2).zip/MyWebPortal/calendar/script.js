const monthYear = document.getElementById('monthYear');
const dates = document.getElementById('dates');

const date = new Date();
const currentDay = date.getDate();
const month = date.getMonth();
const year = date.getFullYear();

const months = ["Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"];

monthYear.innerText = `${months[month]} ${year}`;

// Получаем первый день месяца (чтобы знать сдвиг) и количество дней
const firstDayIndex = new Date(year, month, 0).getDay(); // 0 - Пн
const lastDay = new Date(year, month + 1, 0).getDate();

let daysHTML = "";

// Пустые ячейки до начала месяца
for (let i = 0; i < firstDayIndex; i++) {
    daysHTML += `<div class="empty"></div>`;
}

// Дни месяца
for (let i = 1; i <= lastDay; i++) {
    if (i === currentDay) {
        daysHTML += `<div class="date today">${i}</div>`;
    } else {
        daysHTML += `<div class="date">${i}</div>`;
    }
}

dates.innerHTML = daysHTML;